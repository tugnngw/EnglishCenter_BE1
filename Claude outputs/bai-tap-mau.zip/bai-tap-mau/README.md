# Bài tập mẫu — test "Import PDF" (Homework của mentor)

Kết quả AI nên trả về cho từng file. Dùng bảng này để đối chiếu bản nháp AI điền sẵn trong form.

| File | Kỹ năng | Hình thức nộp AI nên chọn | Điểm tối đa |
|---|---|---|---|
| 01_IELTS_Writing_Task2_Remote_Work.pdf | Writing (essay ≥ 250 từ) | text | 9 |
| 02_IELTS_Writing_Task1_Coffee_Shops.pdf | Writing (mô tả bảng số liệu) | text | 9 |
| 03_IELTS_Speaking_Part2_Memorable_Trip.pdf | Speaking (cue card) | audio | 9 |
| 04_Speaking_Part1_Hometown_Daily_Routine.pdf | Speaking (6 câu hỏi) | audio | 10 |
| 05_TOEIC_Part5_Grammar_10_Questions.pdf | Grammar (10 câu, gõ đáp án 1-B, 2-A…) | text | 10 |
| 06_Reading_Short_Passage_Urban_Gardens.pdf | Reading (T/F/NG + short answer) | text | 10 |
| 07_Vocabulary_Worksheet_Environment_Upload.pdf | Vocabulary (điền bảng rồi upload) | file | 20 |
| 08_TOEIC_Writing_Respond_To_Email.pdf | Writing (trả lời email) | text | 10 |

## Kịch bản test gợi ý

1. Mentor → Homework → Bài tập của tôi → **Import PDF** từng file → kiểm tra tên, đề bài, hình thức nộp, điểm khớp bảng trên → đặt hạn nộp → Tạo.
2. Learning Paths → sửa lộ trình của mentor → thêm chặng **Bài tập mentor** → chọn bài vừa tạo.
3. Student **đã thanh toán gói kèm 1-1** + ghi danh lộ trình → bấm **Làm bài →** → nộp (text / file / ghi âm).
4. Bài vào tab **Chấm bài** của mentor 1-1 → mentor chấm tay (không AI chấm).
5. Chấm đạt → chặng trong lộ trình chuyển sang hoàn thành.
6. Student chưa có gói → chặng hiện **Cần gói kèm 1-1 →**, không mở được bài.
